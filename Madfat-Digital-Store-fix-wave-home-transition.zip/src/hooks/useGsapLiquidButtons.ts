import { useEffect } from 'react';
import { gsap } from 'gsap';

const ORANGE = '#FF7A30';
const OBSIDIAN = '#1C1E1C';
const WHITE = '#FFFFFF';

type LiquidButton = HTMLElement & {
  __madfatLiquidCleanup?: () => void;
};

type LiquidStyle = {
  fill: string;
  text: string;
};

function isDarkBackground(color: string) {
  const match = color.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
  if (!match) return false;
  const [, r, g, b] = match.map(Number);
  const luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b;
  return luminance < 96;
}

function resolveLiquidStyle(button: HTMLElement): LiquidStyle {
  const computed = window.getComputedStyle(button);
  const darkBase = isDarkBackground(computed.backgroundColor) || button.classList.contains('bg-obsidian');

  // Task utama: tombol orange berubah putih, tombol putih berubah hitam.
  if (button.classList.contains('btn-liquid-orange')) {
    return { fill: WHITE, text: OBSIDIAN };
  }

  if (button.classList.contains('btn-liquid-white')) {
    return darkBase ? { fill: WHITE, text: OBSIDIAN } : { fill: OBSIDIAN, text: WHITE };
  }

  if (button.classList.contains('btn-liquid-obsidian')) {
    return { fill: WHITE, text: OBSIDIAN };
  }

  return { fill: ORANGE, text: WHITE };
}

function ensureLiquidLayer(button: HTMLElement) {
  let liquid = button.querySelector<HTMLElement>(':scope > .gsap-liquid-fill');

  if (!liquid) {
    liquid = document.createElement('span');
    liquid.className = 'gsap-liquid-fill';
    liquid.setAttribute('aria-hidden', 'true');

    const wave = document.createElement('span');
    wave.className = 'gsap-liquid-wave';
    liquid.appendChild(wave);

    button.prepend(liquid);
  } else if (!liquid.querySelector(':scope > .gsap-liquid-wave')) {
    const wave = document.createElement('span');
    wave.className = 'gsap-liquid-wave';
    liquid.appendChild(wave);
  }

  return {
    liquid,
    wave: liquid.querySelector<HTMLElement>(':scope > .gsap-liquid-wave')
  };
}

function getTextTargets(button: HTMLElement) {
  return gsap.utils.toArray<HTMLElement>(
    button.querySelectorAll(':scope > *:not(.gsap-liquid-fill), :scope > *:not(.gsap-liquid-fill) *')
  );
}

function bindLiquidButton(button: LiquidButton) {
  if (button.__madfatLiquidCleanup) return;

  const { liquid, wave } = ensureLiquidLayer(button);
  const textTargets = getTextTargets(button);

  gsap.set(liquid, {
    yPercent: 118,
    rotate: 0,
    force3D: true,
    transformOrigin: '50% 100%'
  });

  if (wave) {
    gsap.set(wave, {
      xPercent: -50,
      rotate: 0,
      scaleX: 1,
      transformOrigin: '50% 50%'
    });
  }

  const waveTween = wave
    ? gsap.to(wave, {
        rotate: 360,
        scaleX: 1.08,
        duration: 1.35,
        ease: 'none',
        repeat: -1,
        paused: true,
        yoyo: false
      })
    : null;

  const enter = () => {
    const { fill, text } = resolveLiquidStyle(button);

    button.classList.add('is-liquid-hover');
    gsap.set(liquid, { backgroundColor: fill });
    gsap.set(wave, { backgroundColor: fill });
    waveTween?.restart(true);

    gsap.to(liquid, {
      yPercent: 0,
      duration: 0.36,
      ease: 'power3.out',
      overwrite: 'auto'
    });

    gsap.to([button, ...textTargets], {
      color: text,
      duration: 0.16,
      ease: 'power2.out',
      overwrite: 'auto'
    });

    gsap.to(button, {
      y: 1,
      duration: 0.16,
      ease: 'power2.out',
      overwrite: 'auto'
    });
  };

  const leave = () => {
    button.classList.remove('is-liquid-hover');

    gsap.to(liquid, {
      yPercent: 118,
      duration: 0.34,
      ease: 'power3.inOut',
      overwrite: 'auto',
      onComplete: () => {
        waveTween?.pause(0);
        gsap.set(wave, { rotate: 0, scaleX: 1 });
      }
    });

    gsap.to(button, {
      y: 0,
      scale: 1,
      duration: 0.16,
      ease: 'power2.out',
      overwrite: 'auto'
    });

    gsap.set([button, ...textTargets], {
      clearProps: 'color'
    });
  };

  const down = () => {
    gsap.to(button, {
      scale: 0.985,
      duration: 0.1,
      ease: 'power2.out',
      overwrite: 'auto'
    });
  };

  const up = () => {
    gsap.to(button, {
      scale: 1,
      duration: 0.16,
      ease: 'back.out(2)',
      overwrite: 'auto'
    });
  };

  button.addEventListener('mouseenter', enter);
  button.addEventListener('mouseleave', leave);
  button.addEventListener('mousedown', down);
  button.addEventListener('mouseup', up);
  button.addEventListener('blur', leave);

  button.__madfatLiquidCleanup = () => {
    button.removeEventListener('mouseenter', enter);
    button.removeEventListener('mouseleave', leave);
    button.removeEventListener('mousedown', down);
    button.removeEventListener('mouseup', up);
    button.removeEventListener('blur', leave);
    waveTween?.kill();
    gsap.killTweensOf([button, liquid, wave, ...textTargets]);
    delete button.__madfatLiquidCleanup;
  };
}

export function useGsapLiquidButtons(dependencyKey: string) {
  useEffect(() => {
    const mountedButtons = new Set<LiquidButton>();

    const scan = () => {
      document.querySelectorAll<LiquidButton>('.btn-liquid').forEach((button) => {
        bindLiquidButton(button);
        mountedButtons.add(button);
      });
    };

    scan();
    const delayedScan = window.setTimeout(scan, 80);

    const observer = new MutationObserver(scan);
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['class']
    });

    return () => {
      window.clearTimeout(delayedScan);
      observer.disconnect();
      mountedButtons.forEach((button) => button.__madfatLiquidCleanup?.());
    };
  }, [dependencyKey]);
}
