import React from 'react';

export default function TimelineFlow() {
  return (
    <section className="bg-obsidian py-20 px-6 md:px-12">
      <div className="max-w-5xl mx-auto">
        <h3 className="animate-pop-in font-hero text-center text-3xl sm:text-[40px] font-bold mb-16 text-white uppercase">
          ALUR <span className="text-blaze-orange">PENGERJAAN.</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 relative">
          
          {/* Connector Line in desktop */}
          <div className="hidden md:block absolute top-10 left-16 right-16 h-1 bg-dashed border-t-2 border-dashed border-white/20 z-0" />

          {/* Step 1 */}
          <div className="animate-pop-in text-center relative z-10 p-4">
            <div className="w-20 h-20 bg-blaze-orange text-white rounded-2xl mx-auto mb-6 flex items-center justify-center font-hero text-2xl font-bold border-4 border-obsidian brutalist-shadow-dark rotate-3">
              01
            </div>
            <h4 className="font-hero text-lg font-bold text-white mb-2">Diskusi & Brief</h4>
            <p className="font-sans text-xs sm:text-sm text-white/50 leading-relaxed max-w-xs mx-auto">
              Sampaikan kebutuhan fitur, sitemap menu, serta referensi website impian Anda kepada admin kami.
            </p>
          </div>

          {/* Step 2 */}
          <div className="animate-pop-in text-center relative z-10 p-4">
            <div className="w-20 h-20 bg-white text-obsidian rounded-2xl mx-auto mb-6 flex items-center justify-center font-hero text-2xl font-bold border-4 border-obsidian brutalist-shadow-dark -rotate-6">
              02
            </div>
            <h4 className="font-hero text-lg font-bold text-white mb-2">Proses Development</h4>
            <p className="font-sans text-xs sm:text-sm text-white/50 leading-relaxed max-w-xs mx-auto">
              Kreator kami langsung mengkode layout website Anda dengan interaksi Framer Motion dan kecepatan load tinggi.
            </p>
          </div>

          {/* Step 3 */}
          <div className="animate-pop-in text-center relative z-10 p-4">
            <div className="w-20 h-20 bg-cream-warm text-obsidian rounded-2xl mx-auto mb-6 flex items-center justify-center font-hero text-2xl font-bold border-4 border-obsidian brutalist-shadow-dark rotate-2">
              03
            </div>
            <h4 className="font-hero text-lg font-bold text-white mb-2">Review & Launch</h4>
            <p className="font-sans text-xs sm:text-sm text-white/50 leading-relaxed max-w-xs mx-auto">
              Setelah revisi dan feedback diselesaikan, web siap dirilis online menggunakan setup hosting & domain premium Anda!
            </p>
          </div>

        </div>
      </div>
    </section>
  );
}
