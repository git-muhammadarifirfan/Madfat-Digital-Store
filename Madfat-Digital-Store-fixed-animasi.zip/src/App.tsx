import React, {
  useState,
  useEffect,
  useCallback,
  useMemo,
  Suspense,
  useLayoutEffect,
} from "react";
import { MessageCircle, ArrowRight } from "lucide-react";
import Lenis from "lenis";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

// Register ScrollTrigger
gsap.registerPlugin(ScrollTrigger);

import { DIGITAL_PRODUCTS, WEBSITE_PACKAGES, FAQ_ITEMS } from "./data";
import { DigitalProduct, WebsitePackage, CartItem } from "./types";
import Navbar from "./components/Navbar";
import DigitalProductPage from "./components/DigitalProductPage";
import WebsiteDetailsPage from "./components/WebsiteDetailsPage";

// Lazy load non-critical home components for code splitting
const Cart = React.lazy(() => import("./components/Cart"));
const FAQAccordion = React.lazy(() => import("./components/FAQAccordion"));
const Hero = React.lazy(() => import("./components/Hero"));
const TrustBar = React.lazy(() => import("./components/TrustBar"));
const DigitalCatalog = React.lazy(() => import("./components/DigitalCatalog"));
const WebsitePackages = React.lazy(
  () => import("./components/WebsitePackages"),
);
const TimelineFlow = React.lazy(() => import("./components/TimelineFlow"));
const TestimonialMarquee = React.lazy(
  () => import("./components/TestimonialMarquee"),
);
const Footer = React.lazy(() => import("./components/Footer"));
const FloatingDoodles = React.lazy(
  () => import("./components/FloatingDoodles"),
);

// Loading fallback
const LoadingFallback = () => <div className="min-h-[40vh] bg-surface" />;

export default function App() {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [notification, setNotification] = useState<{
    show: boolean;
    text: string;
  } | null>(null);
  const [currentPath, setCurrentPath] = useState(window.location.pathname);

  useEffect(() => {
    // Reset scroll to top on reload/load
    window.history.scrollRestoration = "manual";
    window.scrollTo(0, 0);
    const globalLenis = (window as any).lenis;
    if (globalLenis) {
      globalLenis.scrollTo(0, { immediate: true });
    }

    const handlePopState = () => {
      setCurrentPath(window.location.pathname);
      // Only scroll to top if the URL does NOT contain a hash target
      if (!window.location.hash) {
        const gl = (window as any).lenis;
        if (gl) {
          gl.scrollTo(0, { immediate: true });
        } else {
          window.scrollTo(0, 0);
        }
      }
    };
    window.addEventListener("popstate", handlePopState);
    return () => window.removeEventListener("popstate", handlePopState);
  }, []);

  // Playful scroll pop-in animations for section headings and tagged text blocks
  useLayoutEffect(() => {
    if (currentPath !== "/") return;

    let cleanupScrollAnimations: (() => void) | undefined;
    const timer = window.setTimeout(() => {
      // Target headings and elements with .animate-pop-in class
      const targets = document.querySelectorAll("h2, h3, .animate-pop-in");
      const anims: gsap.core.Tween[] = [];

      targets.forEach((el) => {
        // Exclude navbar links/brand title and marquee text
        if (
          el.closest("#navbar") ||
          el.closest(".marquee") ||
          el.closest(".nav-sticker")
        )
          return;

        gsap.set(el, {
          scale: 0.82,
          rotate: -2,
          opacity: 0,
          transformOrigin: "center center",
        });

        const anim = gsap.to(el, {
          scale: 1,
          rotate: 0,
          opacity: 1,
          duration: 0.7,
          ease: "back.out(1.6)",
          scrollTrigger: {
            trigger: el,
            start: "top 88%",
            toggleActions: "play none none none",
            once: true,
          },
        });
        anims.push(anim);
      });

      ScrollTrigger.refresh();

      cleanupScrollAnimations = () => {
        anims.forEach((anim) => {
          if (anim.scrollTrigger) {
            anim.scrollTrigger.kill();
          }
          anim.kill();
        });
      };
    }, 80);

    return () => {
      window.clearTimeout(timer);
      cleanupScrollAnimations?.();
    };
  }, [currentPath]);

  useEffect(() => {
    let lenisInstance: Lenis | null = null;
    let rafId: number | null = null;

    // 50ms delay lets React commit layout changes to the DOM first
    const initTimeout = setTimeout(() => {
      try {
        lenisInstance = new Lenis({
          duration: 1.2,
          easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
          orientation: "vertical",
          gestureOrientation: "vertical",
          smoothWheel: true,
        });

        (window as any).lenis = lenisInstance;

        const raf = (time: number) => {
          lenisInstance?.raf(time);
          rafId = requestAnimationFrame(raf);
        };

        rafId = requestAnimationFrame(raf);

        // Force layout dimensions sync immediately
        lenisInstance.resize();

        // Check if there is a hash target in window.location.hash and scroll to it immediately!
        if (window.location.hash) {
          const target = document.querySelector(window.location.hash);
          if (target) {
            setTimeout(() => {
              (window as any).lenis?.scrollTo(target, { duration: 1.5 });
            }, 60);
          }
        }
      } catch (error) {
        console.error("Lenis initialization failed:", error);
      }
    }, 50);

    return () => {
      clearTimeout(initTimeout);
      if (rafId !== null) cancelAnimationFrame(rafId);
      if (lenisInstance) {
        lenisInstance.destroy();
      }
      (window as any).lenis = null;
    };
  }, [currentPath]);

  const triggerNotification = useCallback((text: string) => {
    setNotification({ show: true, text });
    const timeout = setTimeout(() => {
      setNotification(null);
    }, 2800);
    return () => clearTimeout(timeout);
  }, []);

  const handleAddToCart = useCallback(
    (product: DigitalProduct | WebsitePackage) => {
      // If it's a website bundle package, redirect to WhatsApp
      if ("categoryName" in product) {
        const adminWhatsAppNumber = "6281234567890";
        const message = `Halo Admin Madfat! Saya tertarik untuk memesan/berkonsultasi mengenai paket website: ${product.name} (${product.priceText}). Mohon info detailnya.`;
        window.open(
          `https://wa.me/${adminWhatsAppNumber}?text=${encodeURIComponent(message)}`,
          "_blank",
        );
        return;
      }

      setCartItems((prevItems) => {
        const existing = prevItems.find(
          (item) => item.product.id === product.id,
        );
        if (existing) {
          triggerNotification(
            `Jumlah ${product.name} berhasil ditambahkan di keranjang!`,
          );
          return prevItems.map((item) =>
            item.product.id === product.id
              ? { ...item, quantity: item.quantity + 1 }
              : item,
          );
        }
        triggerNotification(
          `Produk ${product.name} telah masuk ke keranjang belanja!`,
        );
        return [...prevItems, { product, quantity: 1, notes: "" }];
      });
    },
    [triggerNotification],
  );

  const handleUpdateQuantity = useCallback(
    (productId: string, quantity: number) => {
      if (quantity < 1) return;
      setCartItems((prevItems) =>
        prevItems.map((item) =>
          item.product.id === productId ? { ...item, quantity } : item,
        ),
      );
    },
    [],
  );

  const handleUpdateNotes = useCallback((productId: string, notes: string) => {
    setCartItems((prevItems) =>
      prevItems.map((item) =>
        item.product.id === productId ? { ...item, notes } : item,
      ),
    );
  }, []);

  const handleRemoveItem = useCallback(
    (productId: string) => {
      setCartItems((prevItems) =>
        prevItems.filter((item) => item.product.id !== productId),
      );
      triggerNotification("Item dihapus dari keranjang.");
    },
    [triggerNotification],
  );

  const handleClearCart = useCallback(() => {
    setCartItems([]);
    triggerNotification("Semua isi keranjang telah dikosongkan.");
  }, [triggerNotification]);

  const formatPrice = useCallback((value: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  }, []);

  const handleDirectWhatsApp = useCallback(() => {
    const adminWhatsAppNumber = "6281234567890";
    const message = `Halo Admin Madfat! Saya ingin berkonsultasi mengenai akun digital premium atau jasa pembuatan website.`;
    window.open(
      `https://wa.me/${adminWhatsAppNumber}?text=${encodeURIComponent(message)}`,
      "_blank",
    );
  }, []);

  const cartCount = useMemo(
    () => cartItems.reduce((acc, item) => acc + item.quantity, 0),
    [cartItems],
  );

  return (
    <div className="min-h-screen bg-surface text-obsidian relative overflow-x-hidden font-sans">
      <Suspense fallback={null}>
        {currentPath === "/" && <FloatingDoodles />}
      </Suspense>

      <div
        key={`route-slide-${currentPath}`}
        className="route-slider"
        aria-hidden="true"
      />

      {notification && (
        <div className="fixed top-20 right-6 md:right-12 z-200 bg-[#E8FBF0] text-[#166534] border-2 border-obsidian px-5 py-3.5 rounded-xl flex items-center gap-3 brutalist-shadow text-xs sm:text-sm font-tag font-bold animate-slide-up-fade">
          <div className="w-6 h-6 rounded-full bg-[#22C55E] text-white flex items-center justify-center font-black border border-obsidian">
            ✓
          </div>
          <span>{notification.text}</span>
        </div>
      )}

      <button
        onClick={handleDirectWhatsApp}
        className="fixed bottom-8 right-8 z-45 bg-[#25D366] text-white border-2 border-obsidian p-4 rounded-full shadow-2xl hover:bg-emerald-600 transition-colors cursor-pointer brutalist-shadow-dark flex items-center justify-center gap-2 group"
      >
        <span className="font-tag text-xs font-black uppercase hidden group-hover:inline-block tracking-wider pl-1 text-white">
          Tanya Admin
        </span>
        <MessageCircle className="w-7 h-7 fill-current stroke-none text-white" />
      </button>

      <Navbar
        cartCount={cartCount}
        onCartClick={() => setIsCartOpen(true)}
        currentPath={currentPath}
      />

      <main
        key={currentPath}
        className={
          currentPath === "/" ? "route-view" : "route-view route-view-subpage"
        }
      >
        {currentPath === "/digitalproduct" ? (
          <DigitalProductPage
            products={DIGITAL_PRODUCTS}
            onAddToCart={handleAddToCart}
            formatPrice={formatPrice}
          />
        ) : currentPath === "/websitedetails" ? (
          <WebsiteDetailsPage
            websitePackages={WEBSITE_PACKAGES}
            onAddToCart={handleAddToCart}
            formatPrice={formatPrice}
          />
        ) : (
          <>
            <Suspense fallback={<LoadingFallback />}>
              <Hero onDirectWhatsApp={handleDirectWhatsApp} />
            </Suspense>

            <Suspense fallback={null}>
              <TrustBar />
            </Suspense>

            <Suspense fallback={<LoadingFallback />}>
              <DigitalCatalog
                products={DIGITAL_PRODUCTS}
                onAddToCart={handleAddToCart}
                formatPrice={formatPrice}
              />
            </Suspense>

            <Suspense fallback={<LoadingFallback />}>
              <WebsitePackages
                websitePackages={WEBSITE_PACKAGES}
                onAddToCart={handleAddToCart}
                onDirectWhatsApp={handleDirectWhatsApp}
              />
            </Suspense>

            <Suspense fallback={<LoadingFallback />}>
              <TimelineFlow />
            </Suspense>

            <section className="py-20 px-6 md:px-12 max-w-7xl mx-auto" id="faq">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
                <div className="lg:col-span-5 flex flex-col justify-between">
                  <div>
                    <h2 className="font-hero text-4xl sm:text-5xl font-bold text-obsidian leading-[1.05] tracking-tight mb-6">
                      PERTANYAAN <br />
                      <span className="text-blaze-orange">UMUM.</span>
                    </h2>
                    <p className="font-sans text-sm sm:text-base text-on-surface-variant mb-10 max-w-md">
                      Punya pertanyaan seputar layanan kami? Berikut adalah
                      beberapa jawaban untuk pertanyaan yang paling sering
                      ditanyakan.
                    </p>
                  </div>

                  <div className="p-6 bg-[#ffecc9] rounded-2xl max-w-md">
                    <h4 className="font-hero text-base font-bold text-obsidian mb-2">
                      Masih bingung?
                    </h4>
                    <p className="font-sans text-xs text-on-surface-variant mb-5">
                      Jangan ragu untuk langsung chat admin kami via WhatsApp
                      untuk konsultasi gratis.
                    </p>
                    <button
                      onClick={handleDirectWhatsApp}
                      className="inline-flex items-center gap-2 font-tag text-xs font-bold text-blaze-orange uppercase group hover:text-obsidian transition-colors cursor-pointer bg-transparent border-none p-0 outline-none"
                    >
                      <span>HUBUNGI KAMI</span>
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
                    </button>
                  </div>
                </div>

                <div className="lg:col-span-7">
                  <Suspense fallback={<LoadingFallback />}>
                    <FAQAccordion items={FAQ_ITEMS} />
                  </Suspense>
                </div>
              </div>
            </section>

            <section className="mx-6 md:mx-12 max-w-7xl lg:mx-auto my-16 bg-blaze-orange text-white rounded-[32px] overflow-hidden relative">
              <div className="relative z-10 px-6 py-20 sm:p-24 flex flex-col items-center text-center max-w-3xl mx-auto">
                <h2 className="font-hero text-4xl sm:text-6xl font-bold text-white tracking-tight leading-none mb-6 uppercase">
                  READY TO <br />
                  <span className="italic block mt-1">LEVEL UP?</span>
                </h2>
                <p className="font-sans text-sm sm:text-base text-white/90 max-w-xl mb-10 leading-relaxed">
                  Jangan tunda pertumbuhan digitalmu. Dapatkan akun premium atau
                  website impianmu hanya dengan beberapa klik.
                </p>

                <button
                  onClick={handleDirectWhatsApp}
                  className="btn-liquid btn-liquid-obsidian px-8.5 py-4.5 bg-obsidian text-white rounded-full font-tag text-xs font-bold tracking-wider flex items-center gap-3.5 group cursor-pointer border-2 border-obsidian"
                >
                  <span className="relative z-10 flex items-center gap-3.5">
                    <span>ORDER VIA WHATSAPP</span>
                    <MessageCircle className="w-4.5 h-4.5 group-hover:rotate-12 transition-transform" />
                  </span>
                </button>
              </div>
            </section>

            <Suspense fallback={<LoadingFallback />}>
              <TestimonialMarquee />
            </Suspense>
          </>
        )}
      </main>

      <Suspense fallback={null}>
        <Footer
          onDirectWhatsApp={handleDirectWhatsApp}
          onCartOpen={() => setIsCartOpen(true)}
        />
      </Suspense>

      <Suspense fallback={null}>
        <Cart
          isOpen={isCartOpen}
          onClose={() => setIsCartOpen(false)}
          cartItems={cartItems}
          onUpdateQuantity={handleUpdateQuantity}
          onUpdateNotes={handleUpdateNotes}
          onRemoveItem={handleRemoveItem}
          onClearCart={handleClearCart}
        />
      </Suspense>
    </div>
  );
}
