import React, { useState } from "react";
import {
  Plus,
  Tv,
  Music,
  Gamepad,
  GraduationCap,
  Sparkles,
  ArrowLeft,
} from "lucide-react";
import { DigitalProduct } from "../types";

interface DigitalProductPageProps {
  products: DigitalProduct[];
  onAddToCart: (product: DigitalProduct) => void;
  formatPrice: (value: number) => string;
}

export default function DigitalProductPage({
  products,
  onAddToCart,
  formatPrice,
}: DigitalProductPageProps) {
  const [activeCategory, setActiveCategory] = useState<
    "all" | "streaming" | "gaming" | "education"
  >("all");

  const filteredProducts =
    activeCategory === "all"
      ? products
      : products.filter((p) => p.category === activeCategory);

  const categories: {
    id: "all" | "streaming" | "gaming" | "education";
    label: string;
  }[] = [
    { id: "all", label: "SEMUA" },
    { id: "streaming", label: "STREAMING" },
    { id: "gaming", label: "GAMING" },
    { id: "education", label: "EDUCATION / AI" },
  ];

  const handleBackToHome = (e: React.MouseEvent) => {
    e.preventDefault();
    window.history.pushState({}, "", "/");
    window.dispatchEvent(new PopStateEvent("popstate"));
  };

  return (
    <div className="subpage-page bg-[#fff8f2] min-h-screen py-24 px-6 md:px-12">
      <div className="max-w-7xl mx-auto">
        {/* Back Button */}
        <div
          className="subpage-pop-item mb-10"
          style={{ "--pop-delay": "20ms" } as React.CSSProperties}
        >
          <a
            href="/"
            onClick={handleBackToHome}
            className="inline-flex items-center gap-2 font-tag text-xs font-bold text-blaze-orange hover:text-obsidian transition-colors uppercase"
          >
            <ArrowLeft className="w-4 h-4 stroke-[3]" />
            <span>Kembali Ke Beranda</span>
          </a>
        </div>

        {/* Page Header */}
        <div
          className="subpage-pop-item mb-12"
          style={{ "--pop-delay": "60ms" } as React.CSSProperties}
        >
          <h1 className="font-hero text-4xl sm:text-5xl md:text-6xl font-bold text-obsidian tracking-tight uppercase mb-4">
            SEMUA AKUN <span className="text-blaze-orange">PREMIUM.</span>
          </h1>
          <p className="font-sans text-sm sm:text-base text-[#5F5B57] max-w-xl">
            Pilih dari seluruh daftar akun premium legal, proses aktivasi
            instan, dan garansi penuh sepanjang masa aktif.
          </p>
        </div>

        {/* Filter Categories */}
        <div
          className="subpage-pop-item flex flex-wrap gap-3 mb-10 select-none"
          style={{ "--pop-delay": "100ms" } as React.CSSProperties}
        >
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`btn-liquid ${
                activeCategory === cat.id
                  ? "btn-liquid-orange bg-blaze-orange text-white"
                  : "btn-liquid-white bg-white text-obsidian"
              } px-6 py-2.5 rounded-full border-2 border-obsidian font-tag text-xs font-bold transition-all shadow-[2px_2px_0px_0px_#1C1E1C] hover:translate-y-[1px] hover:shadow-[1px_1px_0px_0px_#1C1E1C] cursor-pointer`}
            >
              <span className="relative z-10">{cat.label}</span>
            </button>
          ))}
        </div>

        {/* Grid Products - Full items */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredProducts.map((product, index) => (
            <div
              key={product.id}
              className="subpage-pop-card bg-[#f5f0eb] border-2 border-obsidian rounded-2xl shadow-[5px_5px_0px_0px_#1C1E1C] relative overflow-hidden flex flex-row sm:flex-col items-center sm:items-stretch justify-between p-3.5 sm:p-6 gap-3.5 sm:gap-6 flex select-none cursor-default"
              style={
                {
                  willChange: "transform",
                  "--pop-delay": `${140 + index * 35}ms`,
                } as React.CSSProperties
              }
            >
              {/* Top Badges */}
              {product.hot && (
                <span className="absolute top-1.5 right-1.5 sm:top-4 sm:right-4 bg-blaze-orange text-white font-tag text-[8px] sm:text-[9px] font-bold px-2 py-0.5 sm:px-2.5 sm:py-1 rounded border border-obsidian shadow-[1px_1px_0px_0px_#1C1E1C]">
                  HOT
                </span>
              )}
              {product.bestSeller && (
                <span className="absolute top-1.5 right-1.5 sm:top-4 sm:right-4 bg-blaze-orange text-white font-tag text-[8px] sm:text-[9px] font-bold px-2 py-0.5 sm:px-2.5 sm:py-1 rounded border border-obsidian shadow-[1px_1px_0px_0px_#1C1E1C]">
                  BEST
                </span>
              )}

              {/* Left part in mobile (Image Logo) */}
              <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-lg sm:rounded-xl border-2 border-obsidian shadow-[2px_2px_0px_0px_#1C1E1C] shrink-0 overflow-hidden bg-obsidian flex items-center justify-center">
                {product.image ? (
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <span className="font-bold text-lg sm:text-xl text-white">
                    ★
                  </span>
                )}
              </div>

              {/* Middle part in mobile (Texts) */}
              <div className="flex-1 min-w-0 pr-6 sm:pr-0">
                <h3 className="font-hero text-sm sm:text-lg font-bold text-obsidian mb-0.5 truncate">
                  {product.name}
                </h3>
                <p className="font-tag text-[9px] sm:text-[10px] font-bold text-[#8C8A87] mb-1 sm:mb-3 uppercase tracking-wider truncate">
                  {product.sub}
                </p>
                <p className="font-sans text-xs text-[#5F5B57] hidden sm:block mb-6 line-clamp-3 leading-relaxed">
                  {product.description}
                </p>

                {/* Price directly below title in mobile */}
                <div className="sm:hidden">
                  <span className="font-tag text-xs font-bold text-blaze-orange italic">
                    {formatPrice(product.price)}
                  </span>
                </div>
              </div>

              {/* Footer (for Desktop) */}
              <div className="hidden sm:flex items-center justify-between pt-4 border-t-2 border-dashed border-[#dfc0b3] w-full">
                <div>
                  <span className="font-tag text-[9px] font-bold text-[#8C8A87] block uppercase">
                    Harga Mulai
                  </span>
                  <span className="font-tag text-lg font-bold text-blaze-orange italic">
                    {formatPrice(product.price)}
                  </span>
                </div>

                <button
                  onClick={() => onAddToCart(product)}
                  className="btn-liquid btn-liquid-white w-10 h-10 rounded-xl bg-obsidian text-white border-2 border-obsidian flex items-center justify-center cursor-pointer shadow-[2px_2px_0px_0px_#FF7A30]"
                  title="Tambah ke Keranjang"
                >
                  <Plus className="w-5 h-5 stroke-[3] relative z-10" />
                </button>
              </div>

              {/* Mobile Add to Cart Button */}
              <div className="sm:hidden shrink-0">
                <button
                  onClick={() => onAddToCart(product)}
                  className="btn-liquid btn-liquid-white w-9 h-9 rounded-lg bg-obsidian text-white border-2 border-obsidian flex items-center justify-center cursor-pointer shadow-[1.5px_1.5px_0px_0px_#FF7A30]"
                  title="Tambah ke Keranjang"
                >
                  <Plus className="w-4 h-4 stroke-[3] relative z-10" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
