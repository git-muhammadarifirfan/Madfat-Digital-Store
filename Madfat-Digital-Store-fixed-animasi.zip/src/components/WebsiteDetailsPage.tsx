import React from "react";
import { Check, ArrowLeft } from "lucide-react";
import { WebsitePackage } from "../types";

interface WebsiteDetailsPageProps {
  websitePackages: WebsitePackage[];
  onAddToCart: (pack: WebsitePackage) => void;
  formatPrice: (value: number) => string;
}

export default function WebsiteDetailsPage({
  websitePackages,
  onAddToCart,
  formatPrice,
}: WebsiteDetailsPageProps) {
  const handleBackToHome = (e: React.MouseEvent) => {
    e.preventDefault();
    window.history.pushState({}, "", "/");
    window.dispatchEvent(new PopStateEvent("popstate"));
  };

  const getProfessionalFeatures = (pkgId: string) => {
    switch (pkgId) {
      case "bundle-a":
        return [
          "1 Halaman Informasi Utama (Modern Single-Page Design)",
          "Desain Responsif & Mobile-Friendly Teroptimasi",
          "Sitemap: Hero, Profil, Galeri, Kontak, & Maps",
          "Integrasi WhatsApp Call-to-Action Langsung",
          "Waktu Pengerjaan Cepat: 2-4 Hari Kerja",
          "Gratis Re-layout 2x Sesi Revisi",
          "Hosting Gratis di Server Netlify / Vercel",
          "Garansi Monitoring & Maintenance Sistem 1 Bulan",
        ];
      case "bundle-b":
        return [
          "Sistem Etalase Digital Dinamis (5-30 Produk)",
          "Kategorisasi Produk & Penataan Gambar Grid",
          "Keranjang Belanja Manual & Checkout via WhatsApp",
          "Pemasangan Google Maps & Tombol WhatsApp Floating",
          "Optimasi Load Speed & SEO On-Page Basic",
          "Waktu Pengerjaan: 4-7 Hari Kerja",
          "Gratis 3x Sesi Revisi Mayor",
          "Termasuk Hosting Web & Setup Domain Gratis 1 Tahun",
          "Garansi Dukungan Teknis 3 Bulan Penuh",
        ];
      case "bundle-c":
        return [
          "Website Korporat Multi-Page Profesional",
          "Realtime Database & Integrasi Form Input Dinamis",
          "Halaman Portofolio Klien & Profil Tim Interaktif",
          "Keamanan Server SSL dengan HTTPS Terenkripsi",
          "Optimasi Google Search Console & XML Sitemap",
          "Waktu Pengerjaan: 5-9 Hari Kerja",
          "Revisi Desain Fleksibel & Maksimal (Wajar)",
          "Gratis Domain .com/.id + Server Hosting 1 Tahun",
          "Garansi Update Konten & Maintenance 6 Bulan",
        ];
      case "bundle-d":
        return [
          "Sistem Kasir Web & Panel Manajemen Inventaris",
          "Autentikasi Akun Staff & Multi-role Management",
          "Dashboard Analitik Pendapatan & Stok Menipis",
          "Ekspor Laporan Transaksi (Format Excel/PDF)",
          "Teknologi Progressive Web App (PWA) Offline-Ready",
          "Waktu Pengerjaan: 7-14 Hari Kerja",
          "Revisi & Penyesuaian Alur Sistem Sampai Puas",
          "Server VPS Cloud Handal + SSL Premium 1 Tahun",
          "Garansi Sistem & Penanganan Bug Selama 1 Tahun",
        ];
      case "bundle-e":
      default:
        return [
          "Arsitektur Kode Kustom (Next.js / React Native)",
          "Pengembangan Fitur Spesifik dari Nol Sesuai Brief",
          "Desain UI/UX Unik Sesuai Brand Identity",
          "Integrasi API Pihak Ketiga & Payment Gateway",
          "Sistem Database Kompleks Relasional (PostgreSQL)",
          "Waktu Pengerjaan Disesuaikan dengan Skala Project",
          "Sesi Revisi Fleksibel Mengikuti Dokumen Perjanjian",
          "Pengaturan Server Cloud VPS / AWS Siap Pakai",
          "Dukungan Garansi & Perawatan Kustom Sesuai Kontrak",
        ];
    }
  };

  return (
    <div className="subpage-page bg-[#fff8f2] min-h-screen py-24 px-6 md:px-12">
      <div className="max-w-7xl mx-auto">
        {/* Back Button */}
        <div
          className="subpage-pop-item mb-10"
          style={{ "--pop-delay": "20ms" } as React.CSSProperties}
        >
          <a
            href="/"
            onClick={handleBackToHome}
            className="inline-flex items-center gap-2 font-tag text-xs font-bold text-blaze-orange hover:text-obsidian transition-colors uppercase"
          >
            <ArrowLeft className="w-4 h-4 stroke-[3]" />
            <span>Kembali Ke Beranda</span>
          </a>
        </div>

        {/* Page Header */}
        <div
          className="subpage-pop-item mb-16 text-center max-w-3xl mx-auto"
          style={{ "--pop-delay": "70ms" } as React.CSSProperties}
        >
          <h1 className="font-hero text-4xl sm:text-5xl md:text-6xl font-bold text-obsidian tracking-tight uppercase mb-4">
            DETAIL PAKET <span className="text-blaze-orange">WEBSITE.</span>
          </h1>
          <p className="font-sans text-sm sm:text-base text-[#5F5B57] max-w-xl mx-auto">
            Temukan detail lengkap setiap tingkatan paket pembuatan website
            profesional kami, disesuaikan untuk skala bisnis Anda mulai dari
            UMKM hingga Enterprise.
          </p>
        </div>

        {/* Centered Flex Container */}
        <div className="flex flex-wrap justify-center gap-8 max-w-7xl mx-auto">
          {websitePackages.map((pkg, i) => {
            const isOrange = i % 2 === 0;
            const displayTitle = pkg.name.includes(":")
              ? pkg.name.split(":")[1].trim()
              : pkg.name;
            const features = getProfessionalFeatures(pkg.id);
            return (
              <div
                key={pkg.id}
                className={`subpage-pop-card w-full sm:w-[310px] min-h-[620px] py-12 px-7 rounded-[32px] border-2 flex flex-col justify-between relative cursor-default select-none transition-all duration-300 ${
                  isOrange
                    ? "bg-[#FF7A30] border-obsidian text-white shadow-[6px_6px_0px_0px_#ffffff] hover:border-white"
                    : "bg-white border-obsidian text-obsidian shadow-[6px_6px_0px_0px_#FF7A30] hover:border-blaze-orange"
                }`}
                style={
                  {
                    willChange: "transform",
                    "--pop-delay": `${120 + i * 45}ms`,
                  } as React.CSSProperties
                }
              >
                {/* Badge for Featured/Featured-like packages */}
                {pkg.isFeatured && (
                  <span className="absolute top-4 right-4 bg-[#FF7A30] text-white font-tag text-[8px] font-bold px-2.5 py-1 rounded-full border border-obsidian uppercase tracking-wider">
                    {pkg.badge || "MOST POPULAR"}
                  </span>
                )}

                <div>
                  {/* Category Label */}
                  <span
                    className={`block font-tag text-[9px] font-bold uppercase tracking-widest mb-2 ${
                      isOrange ? "text-[#fff2de]/80" : "text-[#8C8A87]"
                    }`}
                  >
                    {pkg.categoryName}
                  </span>

                  {/* Title */}
                  <h4
                    className={`font-hero text-2xl font-bold tracking-tight mb-2 uppercase border-b pb-2 ${
                      isOrange
                        ? "text-white border-white/20"
                        : "text-obsidian border-obsidian/10"
                    }`}
                  >
                    {displayTitle
                      .replace("WEB", "")
                      .replace("BUSINESS", "")
                      .trim()}
                  </h4>

                  {/* Subtitle */}
                  <p
                    className={`font-sans text-xs leading-relaxed mb-6 min-h-[48px] ${
                      isOrange ? "text-[#fff8f2]/95" : "text-[#5F5B57]"
                    }`}
                  >
                    {pkg.sub}
                  </p>

                  {/* Price */}
                  <div className="mb-6">
                    <span
                      className={`text-[9px] uppercase font-bold block tracking-widest ${
                        isOrange ? "text-[#fff8f2]/70" : "text-[#8C8A87]"
                      }`}
                    >
                      Harga Paket
                    </span>
                    <span
                      className={`font-hero text-3xl font-bold italic ${
                        isOrange ? "text-white" : "text-[#FF7A30]"
                      }`}
                    >
                      {pkg.priceText}
                    </span>
                  </div>

                  {/* Features list */}
                  <ul
                    className={`space-y-2 mb-8 text-[11px] font-medium border-t border-dashed pt-4 ${
                      isOrange
                        ? "border-white/20 text-[#fff8f2]/95"
                        : "border-obsidian/10 text-[#5F5B57]"
                    }`}
                  >
                    {features.map((feature, idx) => (
                      <li key={idx} className="flex items-start gap-1.5">
                        <Check
                          className={`w-3.5 h-3.5 flex-shrink-0 mt-0.5 ${
                            isOrange ? "text-white" : "text-[#FF7A30]"
                          }`}
                        />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <button
                  onClick={() => onAddToCart(pkg)}
                  className={`btn-liquid ${
                    isOrange
                      ? "btn-liquid-white bg-white text-obsidian"
                      : "btn-liquid-orange bg-[#FF7A30] text-white"
                  } w-full py-3 rounded-full border-2 border-obsidian font-tag text-xs font-bold tracking-widest uppercase shadow-[6px_6px_0px_0px_#1C1E1C] cursor-pointer`}
                  style={
                    {
                      willChange: "transform",
                      "--pop-delay": `${120 + i * 45}ms`,
                    } as React.CSSProperties
                  }
                >
                  <span className="relative z-10">
                    {pkg.btnText || "PILIH PAKET"}
                  </span>
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
