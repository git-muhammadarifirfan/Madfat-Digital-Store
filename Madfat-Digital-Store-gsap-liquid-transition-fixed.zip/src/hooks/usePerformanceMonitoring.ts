import { useEffect } from 'react';

interface PerformanceMetric {
  name: string;
  value: number;
  rating: 'good' | 'needs-improvement' | 'poor';
}

type LargestContentfulPaintEntry = PerformanceEntry & {
  renderTime?: number;
  loadTime?: number;
};

const getIsProduction = () => {
  try {
    return Boolean((import.meta as ImportMeta & { env?: { PROD?: boolean } }).env?.PROD);
  } catch {
    return false;
  }
};

export const usePerformanceMonitoring = () => {
  useEffect(() => {
    if (typeof window === 'undefined') return;
    if (getIsProduction()) return;

    const onMetric = (metric: PerformanceMetric) => {
      console.log(`%c${metric.name}`, 'color: blue; font-weight: bold', {
        value: metric.value,
        rating: metric.rating,
      });
    };

    try {
      const observer = new PerformanceObserver((list) => {
        const entries = list.getEntries() as LargestContentfulPaintEntry[];
        const lastEntry = entries[entries.length - 1];
        if (!lastEntry) return;

        const value = lastEntry.renderTime || lastEntry.loadTime || lastEntry.startTime || 0;
        onMetric({
          name: 'LCP',
          value,
          rating: value < 2500 ? 'good' : value < 4000 ? 'needs-improvement' : 'poor',
        });
      });
      observer.observe({ entryTypes: ['largest-contentful-paint'] });

      return () => observer.disconnect();
    } catch {
      console.warn('LCP monitoring not supported');
    }
  }, []);
};

export const reportWebVitals = (metric: { value: number }) => {
  if (metric.value < 2500) {
    console.log('✅ Performance is good');
  } else if (metric.value < 4000) {
    console.warn('⚠️ Performance needs improvement');
  } else {
    console.error('❌ Performance is poor');
  }
};

export default usePerformanceMonitoring;
