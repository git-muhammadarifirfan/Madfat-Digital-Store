import { useEffect } from 'react';
import { gsap } from 'gsap';

const ORANGE = '#FF7A30';
const OBSIDIAN = '#1C1E1C';
const WHITE = '#FFFFFF';

type LiquidButton = HTMLElement & {
  __madfatLiquidCleanup?: () => void;
};

function isDarkBackground(color: string) {
  const match = color.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
  if (!match) return false;
  const [, r, g, b] = match.map(Number);
  const luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b;
  return luminance < 80;
}

function resolveLiquidStyle(button: HTMLElement) {
  const computed = window.getComputedStyle(button);
  const darkBase = isDarkBackground(computed.backgroundColor) || button.classList.contains('bg-obsidian');

  if (button.classList.contains('btn-liquid-orange')) {
    return { fill: WHITE, text: OBSIDIAN };
  }

  if (button.classList.contains('btn-liquid-obsidian')) {
    return { fill: WHITE, text: OBSIDIAN };
  }

  if (button.classList.contains('btn-liquid-white')) {
    return darkBase
      ? { fill: WHITE, text: OBSIDIAN }
      : { fill: OBSIDIAN, text: WHITE };
  }

  return { fill: ORANGE, text: WHITE };
}

function ensureLiquidLayer(button: HTMLElement) {
  let liquid = button.querySelector<HTMLElement>(':scope > .gsap-liquid-fill');
  if (!liquid) {
    liquid = document.createElement('span');
    liquid.className = 'gsap-liquid-fill';
    liquid.setAttribute('aria-hidden', 'true');
    button.prepend(liquid);
  }
  return liquid;
}

function bindLiquidButton(button: LiquidButton) {
  if (button.__madfatLiquidCleanup) return;

  const liquid = ensureLiquidLayer(button);
  let originalColor = window.getComputedStyle(button).color;

  gsap.set(liquid, {
    top: '118%',
    rotate: 0,
    scaleX: 1.1,
    transformOrigin: '50% 50%'
  });

  const waveTween = gsap.to(liquid, {
    rotate: 360,
    duration: 2.35,
    ease: 'none',
    repeat: -1,
    paused: true
  });

  const enter = () => {
    originalColor = window.getComputedStyle(button).color;
    const { fill, text } = resolveLiquidStyle(button);
    gsap.set(liquid, { backgroundColor: fill });
    waveTween.play();

    gsap.to(liquid, {
      top: '-78%',
      scaleX: 1.18,
      duration: 0.62,
      ease: 'power3.out',
      overwrite: 'auto'
    });

    gsap.to(button, {
      color: text,
      y: 1,
      duration: 0.22,
      ease: 'power2.out',
      overwrite: 'auto'
    });
  };

  const leave = () => {
    gsap.to(liquid, {
      top: '118%',
      scaleX: 1.05,
      duration: 0.52,
      ease: 'power3.inOut',
      overwrite: 'auto',
      onComplete: () => {
        waveTween.pause(0);
        gsap.set(liquid, { rotate: 0 });
      }
    });

    gsap.to(button, {
      color: originalColor,
      y: 0,
      duration: 0.22,
      ease: 'power2.out',
      overwrite: 'auto'
    });
  };

  const down = () => {
    gsap.to(button, {
      scale: 0.985,
      duration: 0.12,
      ease: 'power2.out',
      overwrite: 'auto'
    });
  };

  const up = () => {
    gsap.to(button, {
      scale: 1,
      duration: 0.18,
      ease: 'back.out(2)',
      overwrite: 'auto'
    });
  };

  button.addEventListener('mouseenter', enter);
  button.addEventListener('mouseleave', leave);
  button.addEventListener('mousedown', down);
  button.addEventListener('mouseup', up);
  button.addEventListener('blur', leave);

  button.__madfatLiquidCleanup = () => {
    button.removeEventListener('mouseenter', enter);
    button.removeEventListener('mouseleave', leave);
    button.removeEventListener('mousedown', down);
    button.removeEventListener('mouseup', up);
    button.removeEventListener('blur', leave);
    waveTween.kill();
    gsap.killTweensOf([button, liquid]);
    delete button.__madfatLiquidCleanup;
  };
}

export function useGsapLiquidButtons(dependencyKey: string) {
  useEffect(() => {
    const mountedButtons = new Set<LiquidButton>();

    const scan = () => {
      document.querySelectorAll<LiquidButton>('.btn-liquid').forEach((button) => {
        bindLiquidButton(button);
        mountedButtons.add(button);
      });
    };

    scan();
    const delayedScan = window.setTimeout(scan, 80);

    const observer = new MutationObserver(scan);
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['class']
    });

    return () => {
      window.clearTimeout(delayedScan);
      observer.disconnect();
      mountedButtons.forEach((button) => button.__madfatLiquidCleanup?.());
    };
  }, [dependencyKey]);
}
