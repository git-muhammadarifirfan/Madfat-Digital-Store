import React from 'react';
import { Check } from 'lucide-react';
import { WebsitePackage } from '../types';

interface WebsitePackagesProps {
  websitePackages: WebsitePackage[];
  onAddToCart: (pack: WebsitePackage) => void;
  onDirectWhatsApp: () => void;
}

export default function WebsitePackages({
  websitePackages,
  onAddToCart,
  onDirectWhatsApp
}: WebsitePackagesProps) {
  // Use the first 5 packages
  const activePackages = websitePackages.slice(0, 5);

  return (
    <section className="bg-obsidian py-24 px-6 md:px-12 relative overflow-hidden" id="website">
      <div className="max-w-7xl mx-auto relative z-10">

        {/* Section Header */}
        <div className="flex flex-col items-center text-center mb-16 max-w-3xl mx-auto">
          <h2 className="animate-pop-in font-hero text-4xl sm:text-5xl md:text-6xl font-bold text-[#fff8f2] leading-[1.05] tracking-tight uppercase mb-6">
            BUAT BISNIS <br />
            GO DIGITAL <br />
            <span className="text-blaze-orange">SEKARANG.</span>
          </h2>
          <p className="animate-pop-in font-sans text-sm sm:text-base text-white/50 max-w-lg leading-relaxed">
            Solusi pembuatan website profesional dengan performa tinggi, desain modern, dan teroptimasi SEO.
          </p>
        </div>

        {/* Pricing Grid */}
        <div className="mt-16">
          <h3 className="animate-pop-in font-hero text-center text-2xl sm:text-3xl font-bold mb-12 uppercase tracking-wide text-white">
            Pilihan Paket <span className="text-glow-peach block sm:inline italic">Website</span>
          </h3>

          {/* Centered Flex Container */}
          <div className="flex flex-wrap justify-center gap-8 max-w-7xl mx-auto">
            {activePackages.map((pkg, i) => {
              // Alternate style: Index 0, 2 are Orange | Index 1, 3 are White
              const isOrange = i % 2 === 0;

              // Extract package display title
              const displayTitle = pkg.name.includes(':') ? pkg.name.split(':')[1].trim() : pkg.name;

              return (
                <div
                  key={pkg.id}
                  className={`animate-pop-in w-full sm:w-[310px] min-h-[620px] py-12 px-7 rounded-[32px] border-2 flex flex-col justify-between relative cursor-default select-none transition-all duration-300 ${
                    isOrange
                      ? 'bg-[#FF7A30] border-obsidian text-white shadow-[6px_6px_0px_0px_#ffffff] hover:border-white'
                      : 'bg-white border-obsidian text-obsidian shadow-[6px_6px_0px_0px_#FF7A30] hover:border-blaze-orange'
                  }`}
                  style={{ willChange: 'transform' }}
                >
                  {/* Badge position for Pro card */}
                  {pkg.isFeatured && (
                    <span className="absolute top-4 right-4 bg-[#FF7A30] text-white font-tag text-[8px] font-bold px-2.5 py-1 rounded-full border border-obsidian uppercase tracking-wider">
                      {pkg.badge || 'MOST POPULAR'}
                    </span>
                  )}

                  <div>
                    {/* Category Label */}
                    <span
                      className={`block font-tag text-[9px] font-bold uppercase tracking-widest mb-2 ${
                        isOrange ? 'text-[#fff2de]/80' : 'text-[#8C8A87]'
                      }`}
                    >
                      {pkg.categoryName}
                    </span>

                    {/* Title */}
                    <h4
                      className={`font-hero text-2xl font-bold tracking-tight mb-2 uppercase border-b pb-2 ${
                        isOrange ? 'text-white border-white/20' : 'text-obsidian border-obsidian/10'
                      }`}
                    >
                      {displayTitle.replace('WEB', '').replace('BUSINESS', '').trim()}
                    </h4>

                    {/* Subtitle */}
                    <p
                      className={`font-sans text-xs leading-relaxed mb-6 min-h-[48px] ${
                        isOrange ? 'text-[#fff8f2]/95' : 'text-[#5F5B57]'
                      }`}
                    >
                      {pkg.sub}
                    </p>

                    {/* Price */}
                    <div className="mb-6">
                      <span
                        className={`text-[9px] uppercase font-bold block tracking-widest ${
                          isOrange ? 'text-[#fff8f2]/70' : 'text-[#8C8A87]'
                        }`}
                      >
                        Harga Paket
                      </span>
                      <span
                        className={`font-hero text-3xl font-bold italic ${
                          isOrange ? 'text-white' : 'text-[#FF7A30]'
                        }`}
                      >
                        {pkg.priceText}
                      </span>
                    </div>

                    {/* Features list */}
                    <ul
                      className={`space-y-2 mb-8 text-[11px] font-medium border-t border-dashed pt-4 ${
                        isOrange ? 'border-white/20 text-[#fff8f2]/95' : 'border-obsidian/10 text-[#5F5B57]'
                      }`}
                    >
                      {pkg.features.slice(0, 5).map((feature, idx) => (
                        <li key={idx} className="flex items-start gap-1.5">
                          <Check
                            className={`w-3.5 h-3.5 flex-shrink-0 mt-0.5 ${
                              isOrange ? 'text-white' : 'text-[#FF7A30]'
                            }`}
                          />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <button
                    onClick={() => onAddToCart(pkg)}
                    className={`btn-liquid ${
                      isOrange ? 'btn-liquid-white bg-white text-obsidian' : 'btn-liquid-orange bg-[#FF7A30] text-white'
                    } w-full py-3 rounded-full border-2 border-obsidian font-tag text-xs font-bold tracking-widest uppercase shadow-[6px_6px_0px_0px_#1C1E1C] cursor-pointer`}
                    style={{ willChange: 'transform' }}
                  >
                    <span className="relative z-10">{pkg.btnText || 'PILIH PAKET'}</span>
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        {/* See More Details Button */}
        <div className="mt-12 text-center select-none">
          <a
            href="/websitedetails"
            onClick={(e) => {
              e.preventDefault();
              window.history.pushState({}, '', '/websitedetails');
              window.dispatchEvent(new PopStateEvent('popstate'));
            }}
            className="btn-liquid btn-liquid-orange inline-block px-10 py-4 bg-[#FF7A30] text-white rounded-full font-tag text-xs font-bold tracking-wider uppercase border-2 border-obsidian shadow-[4px_4px_0px_0px_#ffffff] hover:translate-y-[1px] hover:shadow-[3px_3px_0px_0px_#ffffff] active:translate-y-[2px] active:shadow-[1px_1px_0px_0px_#ffffff] transition-all duration-150"
          >
            <span className="relative z-10">LIHAT LEBIH DETAIL</span>
          </a>
        </div>

      </div>
    </section>
  );
}

